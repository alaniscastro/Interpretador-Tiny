package interpreter.expr;

public enum UnaryOp {
    Neg,
    Size,
    Not,
    Read,
    ToNumber,
    ToString
}